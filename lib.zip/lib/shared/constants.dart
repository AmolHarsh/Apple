import 'package:flutter/material.dart';

class Constants{
  final primaryColor = Colors.green;
}